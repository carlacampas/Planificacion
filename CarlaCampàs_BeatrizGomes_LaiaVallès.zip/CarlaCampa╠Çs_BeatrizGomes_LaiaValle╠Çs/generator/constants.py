EXTENSIONS = [1,2,3,4]      # Generate problems for extensions included in list
N_PROBLEMS = 20     # Number of problems to generate for each extension
